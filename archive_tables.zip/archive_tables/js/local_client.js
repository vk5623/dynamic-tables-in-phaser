function sendData(name, rememberMe){
    var url = "ws://127.0.0.1:3000/";

    var data = {
        "name": name,
        "remember_me": rememberMe
    };
    var w = new WebSocket(url);
    w.onload =function() {
        w.send(JSON.stringify(data));

    }

}